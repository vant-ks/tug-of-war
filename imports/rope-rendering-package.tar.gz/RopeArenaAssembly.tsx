// ─────────────────────────────────────────────────────────────────────────────
// RopeArenaAssembly.tsx
//
// Reference integration component showing how to wire RopeRenderer,
// KnotRenderer, RopeSnapEffect, useRopePhysics, and usePullPulse together
// into your arena display.
//
// This is NOT meant to be dropped in as-is — it's a working reference
// that demonstrates the connection points. Adapt it into your existing
// ArenaDisplay component.
//
// The SVG viewBox is 800x800 with the arena circle centered at (400,400)
// with radius 320. Adjust these to match your arena layout.
// ─────────────────────────────────────────────────────────────────────────────

import React, { useState, useEffect, useCallback } from 'react';
import RopeRenderer from './RopeRenderer';
import KnotRenderer from './KnotRenderer';
import RopeSnapEffect from './RopeSnapEffect';
import useRopePhysics from './useRopePhysics';
import usePullPulse from './usePullPulse';

const TEAM_COLORS = [
  { name: 'Red',    bg: '#E53935', light: '#EF5350' },
  { name: 'Green',  bg: '#43A047', light: '#66BB6A' },
  { name: 'Blue',   bg: '#1E88E5', light: '#42A5F5' },
  { name: 'Yellow', bg: '#FDD835', light: '#FFEE58' },
];

// Arena geometry
const VIEW = 800;
const CX = VIEW / 2;        // 400 — arena center X
const CY = VIEW / 2;        // 400 — arena center Y
const ARENA_R = 320;         // arena circle radius
const KNOT_SIZE = 14;        // knot SVG radius

interface Team {
  id: number;
  name: string;
  colorIdx: number;
}

export default function RopeArenaAssembly({ teams }: { teams: Team[] }) {
  const n = teams.length;

  // ─── Physics + Pulse hooks ───────────────────────────────────────────
  const {
    knotX, knotY,           // normalized -1..1
    teamTensions,           // per-team 0..1
    totalTension,           // overall strain 0..1
    dominantTeamIdx,
    applyPull,
    reset: resetPhysics,
  } = useRopePhysics({ teamCount: n, damping: 0.92, stiffness: 0.004 });

  const { pulseStates, triggerPulse, resetAll: resetPulses } = usePullPulse(n);

  // ─── Snap effect state ───────────────────────────────────────────────
  const [snapActive, setSnapActive] = useState(false);
  const [recentPull, setRecentPull] = useState(false);

  // ─── Coordinate mapping ──────────────────────────────────────────────
  // Convert normalized knot position to SVG coordinates
  const knotSvgX = CX + knotX * (ARENA_R * 0.85);
  const knotSvgY = CY + knotY * (ARENA_R * 0.85);

  // Team anchor points on arena edge
  const teamAnchors = teams.map((_, i) => {
    const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
    return {
      x: CX + Math.cos(angle) * ARENA_R,
      y: CY + Math.sin(angle) * ARENA_R,
    };
  });

  // ─── Handle incoming pull (call this from your BroadcastChannel handler) ──
  const handlePull = useCallback((teamIdx: number, power: number = 1) => {
    applyPull(teamIdx, power);
    triggerPulse(teamIdx);

    // Brief "recent pull" flag for knot jiggle
    setRecentPull(true);
    setTimeout(() => setRecentPull(false), 200);
  }, [applyPull, triggerPulse]);

  // ─── Trigger snap (call this when round ends) ────────────────────────
  const triggerSnap = useCallback(() => {
    setSnapActive(true);
  }, []);

  // ─── Reset everything (call this on game reset) ──────────────────────
  const resetAll = useCallback(() => {
    resetPhysics();
    resetPulses();
    setSnapActive(false);
    setRecentPull(false);
  }, [resetPhysics, resetPulses]);

  // ─── Demo: simulate random pulls (REMOVE in production) ─────────────
  useEffect(() => {
    const iv = setInterval(() => {
      const ti = Math.floor(Math.random() * n);
      handlePull(ti, 1 + Math.random() * 3);
    }, 200);
    return () => clearInterval(iv);
  }, [n, handlePull]);

  // ─── Render ──────────────────────────────────────────────────────────
  return (
    <svg viewBox={`0 0 ${VIEW} ${VIEW}`}
      style={{ width: '100%', height: '100%', background: '#050510' }}
    >
      {/* Arena circle background */}
      <circle cx={CX} cy={CY} r={ARENA_R}
        fill="#0a0a1a" stroke="rgba(255,255,255,0.08)" strokeWidth={1} />

      {/* Grid rings */}
      {[0.25, 0.5, 0.75].map(f => (
        <circle key={f} cx={CX} cy={CY} r={ARENA_R * f}
          fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth={0.5} />
      ))}

      {/* Team sector fills (same as your existing arena) */}
      {teams.map((t, i) => {
        const startAngle = (i / n) * Math.PI * 2 - Math.PI / 2 - Math.PI / n;
        const endAngle = startAngle + (Math.PI * 2) / n;
        const r = ARENA_R;
        const x1 = CX + Math.cos(startAngle) * r;
        const y1 = CY + Math.sin(startAngle) * r;
        const x2 = CX + Math.cos(endAngle) * r;
        const y2 = CY + Math.sin(endAngle) * r;
        const large = n <= 2 ? 1 : 0;
        return (
          <path key={`sec-${i}`}
            d={`M${CX},${CY} L${x1},${y1} A${r},${r} 0 ${large},1 ${x2},${y2} Z`}
            fill={TEAM_COLORS[t.colorIdx].bg}
            opacity={0.08 + teamTensions[i] * 0.12}
          />
        );
      })}

      {/* ═══ ROPES ═══ */}
      {teams.map((t, i) => (
        <RopeRenderer
          key={`rope-${i}`}
          id={`rope-${i}`}
          startX={teamAnchors[i].x}
          startY={teamAnchors[i].y}
          endX={knotSvgX}
          endY={knotSvgY}
          color={TEAM_COLORS[t.colorIdx].bg}
          tension={teamTensions[i]}
          teamName={t.name}
          pulseActive={pulseStates[i]}
          thickness={5}
          strandCount={3}
          sagAmount={40}
        />
      ))}

      {/* ═══ KNOT ═══ */}
      <KnotRenderer
        x={knotSvgX}
        y={knotSvgY}
        size={KNOT_SIZE}
        totalTension={totalTension}
        dominantColor={TEAM_COLORS[teams[dominantTeamIdx]?.colorIdx || 0].bg}
        isActive={true}
        recentPull={recentPull}
        id="center-knot"
      />

      {/* ═══ SNAP EFFECT ═══ */}
      <RopeSnapEffect
        active={snapActive}
        knotX={knotX}
        knotY={knotY}
        teams={teams}
        arenaSize={VIEW}
        onComplete={() => setSnapActive(false)}
      />

      {/* Team labels */}
      {teams.map((t, i) => {
        const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
        const lx = CX + Math.cos(angle) * (ARENA_R + 30);
        const ly = CY + Math.sin(angle) * (ARENA_R + 30);
        return (
          <text key={`lbl-${i}`} x={lx} y={ly}
            textAnchor="middle" dominantBaseline="central"
            fill={TEAM_COLORS[t.colorIdx].light}
            fontSize={16} fontWeight="600"
            fontFamily="'Segoe UI', sans-serif"
          >
            {t.name}
          </text>
        );
      })}
    </svg>
  );
}

// ─── Exports for external use ────────────────────────────────────────────────
// Your ArenaDisplay component should:
//
// 1. Import useRopePhysics + usePullPulse hooks directly
// 2. Call applyPull(teamIdx, power) from your BroadcastChannel handler
// 3. Render <RopeRenderer> for each team inside your existing <svg>
// 4. Render <KnotRenderer> at the computed knot SVG position
// 5. Render <RopeSnapEffect> and set active=true when round ends
//
// The RopeArenaAssembly above shows exactly how those pieces connect.
// The demo interval at the bottom simulates pulls — remove it and wire
// your real BroadcastChannel "pull" messages to handlePull() instead.
