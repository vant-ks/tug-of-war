// ─────────────────────────────────────────────────────────────────────────────
// usePullPulse.ts
//
// Manages per-team "pulse active" booleans that fire for a short duration
// whenever a pull is received. Feed these into RopeRenderer's pulseActive prop
// to trigger the traveling light effect along the rope.
//
// Usage:
//   const { pulseStates, triggerPulse } = usePullPulse(4); // 4 teams
//
//   // When a pull comes in:
//   triggerPulse(teamIndex);
//
//   // In render:
//   <RopeRenderer pulseActive={pulseStates[i]} ... />
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useRef, useCallback } from 'react';

interface PullPulseResult {
  pulseStates: boolean[];
  triggerPulse: (teamIdx: number) => void;
  resetAll: () => void;
}

export default function usePullPulse(teamCount: number, pulseDurationMs: number = 300): PullPulseResult {
  const [pulseStates, setPulseStates] = useState<boolean[]>(
    () => new Array(teamCount).fill(false)
  );
  const timers = useRef<(ReturnType<typeof setTimeout> | null)[]>(
    new Array(teamCount).fill(null)
  );

  const triggerPulse = useCallback((teamIdx: number) => {
    if (teamIdx < 0 || teamIdx >= teamCount) return;

    // Clear existing timer for this team
    if (timers.current[teamIdx]) {
      clearTimeout(timers.current[teamIdx]!);
    }

    // Set active
    setPulseStates(prev => {
      const next = [...prev];
      next[teamIdx] = true;
      return next;
    });

    // Auto-clear after duration
    timers.current[teamIdx] = setTimeout(() => {
      setPulseStates(prev => {
        const next = [...prev];
        next[teamIdx] = false;
        return next;
      });
      timers.current[teamIdx] = null;
    }, pulseDurationMs);
  }, [teamCount, pulseDurationMs]);

  const resetAll = useCallback(() => {
    timers.current.forEach(t => t && clearTimeout(t));
    timers.current = new Array(teamCount).fill(null);
    setPulseStates(new Array(teamCount).fill(false));
  }, [teamCount]);

  return { pulseStates, triggerPulse, resetAll };
}
