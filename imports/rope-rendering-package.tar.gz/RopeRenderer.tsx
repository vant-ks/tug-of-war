// ─────────────────────────────────────────────────────────────────────────────
// RopeRenderer.tsx
// 
// Pure SVG rope rendering with braided strand texture, catenary sag,
// tension-based animation, and snap/recoil effects.
//
// Props:
//   startX, startY   - anchor point (edge of arena)
//   endX, endY       - knot attachment point
//   color             - team color hex string
//   tension           - 0..1 normalized pull force (affects sag, thickness, glow)
//   teamName          - label for accessibility
//   pulseActive       - boolean, triggers pull-pulse animation
//   thickness         - base rope thickness (default 4)
//   strandCount       - number of braid strands (default 3)
//   sagAmount         - max sag in px when tension=0 (default 30)
//   id                - unique id for SVG defs (required, e.g. "rope-0")
//
// Usage:
//   <svg viewBox="...">
//     <RopeRenderer id="rope-0" startX={0} startY={200} endX={400} endY={200}
//       color="#E53935" tension={0.6} teamName="Red" pulseActive={true} />
//   </svg>
// ─────────────────────────────────────────────────────────────────────────────

import React, { useMemo } from 'react';

// ─── Catenary / sag curve builder ────────────────────────────────────────────
// Returns an SVG path string for a rope with gravity sag perpendicular to 
// the start→end line. Sag decreases as tension increases.

function buildRopePath(sx, sy, ex, ey, tension, sagMax) {
  const mx = (sx + ex) / 2;
  const my = (sy + ey) / 2;
  const dx = ex - sx;
  const dy = ey - sy;
  const len = Math.sqrt(dx * dx + dy * dy);
  if (len < 0.01) return `M${sx},${sy}L${ex},${ey}`;

  // Perpendicular direction (sag direction — "down" relative to rope line)
  const nx = -dy / len;
  const ny = dx / len;

  // Sag decreases with tension: full sag at 0, near-zero at 1
  const sag = sagMax * (1 - tension * 0.85);

  // Control points for a cubic bezier that approximates catenary sag
  const cp1x = sx + dx * 0.3 + nx * sag;
  const cp1y = sy + dy * 0.3 + ny * sag;
  const cp2x = sx + dx * 0.7 + nx * sag * 0.9;
  const cp2y = sy + dy * 0.7 + ny * sag * 0.9;

  return `M${sx},${sy} C${cp1x},${cp1y} ${cp2x},${cp2y} ${ex},${ey}`;
}

// ─── Strand offset paths ─────────────────────────────────────────────────────
// Build parallel offset paths for braid strands. Each strand is offset 
// perpendicular to the rope line by a small amount.

function buildStrandPaths(sx, sy, ex, ey, tension, sagMax, strandCount, thickness) {
  const dx = ex - sx;
  const dy = ey - sy;
  const len = Math.sqrt(dx * dx + dy * dy);
  if (len < 0.01) return [buildRopePath(sx, sy, ex, ey, tension, sagMax)];

  // Perpendicular unit vector
  const nx = -dy / len;
  const ny = dx / len;

  const paths = [];
  const spread = thickness * 0.35;

  for (let i = 0; i < strandCount; i++) {
    // Offset from center: -spread to +spread
    const t = strandCount === 1 ? 0 : (i / (strandCount - 1) - 0.5) * 2;
    const offset = t * spread;

    // Apply sine-wave weave along the rope length for braid effect
    // We sample multiple points and build a polyline-ish path
    const points = [];
    const segments = 20;
    for (let s = 0; s <= segments; s++) {
      const frac = s / segments;

      // Base catenary position at this fraction
      const sag = sagMax * (1 - tension * 0.85);
      // Cubic bezier evaluated manually (approximate)
      const bx = sx + dx * frac + nx * sag * 4 * frac * (1 - frac);
      const by = sy + dy * frac + ny * sag * 4 * frac * (1 - frac);

      // Braid weave: sinusoidal cross-offset
      const weaveFreq = 3 + strandCount; // more strands = tighter weave
      const weaveAmp = spread * 0.6;
      const weavePhase = (i / strandCount) * Math.PI * 2;
      const weave = Math.sin(frac * Math.PI * 2 * weaveFreq + weavePhase) * weaveAmp;

      // Combine perpendicular offset + weave
      const totalOffset = offset + weave * (1 - tension * 0.5); // weave dampens with tension
      points.push({
        x: bx + nx * totalOffset,
        y: by + ny * totalOffset,
      });
    }

    // Build smooth path through points using quadratic beziers
    let d = `M${points[0].x},${points[0].y}`;
    for (let p = 1; p < points.length - 1; p++) {
      const cpx = points[p].x;
      const cpy = points[p].y;
      const epx = (points[p].x + points[p + 1].x) / 2;
      const epy = (points[p].y + points[p + 1].y) / 2;
      d += ` Q${cpx},${cpy} ${epx},${epy}`;
    }
    const last = points[points.length - 1];
    d += ` L${last.x},${last.y}`;
    paths.push(d);
  }

  return paths;
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function RopeRenderer({
  id,
  startX,
  startY,
  endX,
  endY,
  color,
  tension = 0,
  teamName = '',
  pulseActive = false,
  thickness = 4,
  strandCount = 3,
  sagAmount = 30,
}) {
  // Clamp tension
  const t = Math.max(0, Math.min(1, tension));

  // Dynamic thickness: rope gets thinner when taut
  const dynThickness = thickness * (1 - t * 0.3);

  // Core rope path (used for glow and hit area)
  const corePath = useMemo(
    () => buildRopePath(startX, startY, endX, endY, t, sagAmount),
    [startX, startY, endX, endY, t, sagAmount]
  );

  // Individual strand paths
  const strands = useMemo(
    () => buildStrandPaths(startX, startY, endX, endY, t, sagAmount, strandCount, dynThickness),
    [startX, startY, endX, endY, t, sagAmount, strandCount, dynThickness]
  );

  // Color variants
  const colorDark = adjustBrightness(color, -40);
  const colorLight = adjustBrightness(color, 40);
  const glowOpacity = 0.15 + t * 0.45;
  const glowRadius = 2 + t * 6;

  return (
    <g aria-label={`Rope for ${teamName}`}>
      {/* Defs for this rope instance */}
      <defs>
        {/* Glow filter */}
        <filter id={`${id}-glow`} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur in="SourceGraphic" stdDeviation={glowRadius} result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        {/* Pulse animation gradient (travels along rope) */}
        <linearGradient id={`${id}-pulse`} x1="0%" y1="0%" x2="100%" y2="0%"
          gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={color} stopOpacity="0" />
          <stop offset="40%" stopColor="#fff" stopOpacity={pulseActive ? 0.6 : 0} />
          <stop offset="50%" stopColor="#fff" stopOpacity={pulseActive ? 0.9 : 0} />
          <stop offset="60%" stopColor="#fff" stopOpacity={pulseActive ? 0.6 : 0} />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
          {pulseActive && (
            <>
              <animate attributeName="x1" values="-100%;100%" dur="0.6s" repeatCount="indefinite" />
              <animate attributeName="x2" values="0%;200%" dur="0.6s" repeatCount="indefinite" />
            </>
          )}
        </linearGradient>
      </defs>

      {/* Outer glow layer */}
      <path d={corePath}
        fill="none"
        stroke={color}
        strokeWidth={dynThickness * 2.5}
        strokeLinecap="round"
        opacity={glowOpacity}
        filter={`url(#${id}-glow)`}
        style={{ transition: 'stroke-width 0.3s, opacity 0.3s' }}
      />

      {/* Shadow / depth layer */}
      <path d={corePath}
        fill="none"
        stroke={colorDark}
        strokeWidth={dynThickness * 1.4}
        strokeLinecap="round"
        opacity={0.6}
        style={{ transition: 'stroke-width 0.3s' }}
      />

      {/* Individual braid strands */}
      {strands.map((strandPath, i) => {
        // Alternate strand colors for braid depth
        const strandColor = i % 2 === 0 ? color : colorLight;
        const strandW = dynThickness * (0.35 - (i % 2) * 0.05);
        return (
          <path key={i}
            d={strandPath}
            fill="none"
            stroke={strandColor}
            strokeWidth={strandW}
            strokeLinecap="round"
            opacity={0.85 + (i % 2) * 0.15}
            style={{ transition: 'stroke-width 0.3s, d 0.15s' }}
          />
        );
      })}

      {/* Highlight / specular strand along center */}
      <path d={corePath}
        fill="none"
        stroke={colorLight}
        strokeWidth={dynThickness * 0.15}
        strokeLinecap="round"
        opacity={0.4 + t * 0.3}
        style={{ transition: 'stroke-width 0.3s, opacity 0.3s' }}
      />

      {/* Pull pulse overlay */}
      {pulseActive && (
        <path d={corePath}
          fill="none"
          stroke={`url(#${id}-pulse)`}
          strokeWidth={dynThickness * 1.2}
          strokeLinecap="round"
          opacity={0.8}
        />
      )}

      {/* Anchor point nub (where rope meets arena edge) */}
      <circle cx={startX} cy={startY} r={dynThickness * 0.7}
        fill={colorDark} stroke={color} strokeWidth={1}
        opacity={0.9}
      />
    </g>
  );
}

// ─── Utility: adjust hex brightness ──────────────────────────────────────────

function adjustBrightness(hex, amount) {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.max(0, Math.min(255, ((num >> 16) & 0xff) + amount));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amount));
  const b = Math.max(0, Math.min(255, (num & 0xff) + amount));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}
