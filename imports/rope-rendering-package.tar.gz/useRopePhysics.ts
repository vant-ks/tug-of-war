// ─────────────────────────────────────────────────────────────────────────────
// useRopePhysics.ts
//
// Spring-based physics hook that computes the knot position based on
// team pull forces. Returns smoothly animated x,y coordinates and
// per-team tension values normalized 0..1.
//
// This replaces raw state updates with a proper spring simulation that
// gives the knot momentum, overshoot, and damped settling.
//
// Usage:
//   const { knotX, knotY, teamTensions, totalTension, dominantTeamIdx, applyPull }
//     = useRopePhysics({ teamCount: 3, damping: 0.92, stiffness: 0.004 });
//
//   // When a pull comes in from a player:
//   applyPull(teamIndex, power);  // power typically 1 for tap, 5 for trivia
//
//   // knotX, knotY are in normalized space (-1..1)
//   // teamTensions is array of 0..1 per team
//   // totalTension is 0..1 overall strain
//   // dominantTeamIdx is index of team pulling hardest
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useRef, useEffect, useCallback } from 'react';

interface RopePhysicsConfig {
  teamCount: number;       // 2–4 teams
  damping?: number;        // velocity damping per frame (0.90–0.98, default 0.92)
  stiffness?: number;      // spring constant pulling knot toward target (default 0.004)
  maxForceDecay?: number;  // how fast accumulated force decays (default 0.995)
  arenaRadius?: number;    // max normalized distance from center (default 0.9)
}

interface RopePhysicsResult {
  knotX: number;             // normalized -1..1
  knotY: number;             // normalized -1..1
  teamTensions: number[];    // per-team 0..1
  totalTension: number;      // overall 0..1
  dominantTeamIdx: number;   // index of team with most force
  applyPull: (teamIdx: number, power?: number) => void;
  reset: () => void;
}

export default function useRopePhysics({
  teamCount,
  damping = 0.92,
  stiffness = 0.004,
  maxForceDecay = 0.995,
  arenaRadius = 0.9,
}: RopePhysicsConfig): RopePhysicsResult {
  // Team angles: evenly distributed, starting from top (-PI/2)
  const teamAngles = useRef<number[]>([]);
  useEffect(() => {
    teamAngles.current = Array.from({ length: teamCount }, (_, i) =>
      (i / teamCount) * Math.PI * 2 - Math.PI / 2
    );
  }, [teamCount]);

  // Accumulated forces per team
  const forces = useRef<number[]>(new Array(teamCount).fill(0));

  // Physics state
  const posRef = useRef({ x: 0, y: 0 });
  const velRef = useRef({ x: 0, y: 0 });

  // Output state (re-renders on each frame)
  const [state, setState] = useState({
    knotX: 0,
    knotY: 0,
    teamTensions: new Array(teamCount).fill(0) as number[],
    totalTension: 0,
    dominantTeamIdx: 0,
  });

  const rafRef = useRef<number>(0);
  const activeRef = useRef(true);

  // Apply a pull impulse for a team
  const applyPull = useCallback((teamIdx: number, power: number = 1) => {
    if (teamIdx >= 0 && teamIdx < forces.current.length) {
      forces.current[teamIdx] += power;
    }
  }, []);

  // Reset everything
  const reset = useCallback(() => {
    forces.current = new Array(teamCount).fill(0);
    posRef.current = { x: 0, y: 0 };
    velRef.current = { x: 0, y: 0 };
    setState({
      knotX: 0,
      knotY: 0,
      teamTensions: new Array(teamCount).fill(0),
      totalTension: 0,
      dominantTeamIdx: 0,
    });
  }, [teamCount]);

  // Physics tick
  useEffect(() => {
    activeRef.current = true;

    const tick = () => {
      if (!activeRef.current) return;

      const angles = teamAngles.current;
      const n = angles.length;
      if (n < 2) {
        rafRef.current = requestAnimationFrame(tick);
        return;
      }

      // Compute target position from team forces
      const totalForce = forces.current.reduce((a, b) => a + b, 0) || 1;
      let tx = 0, ty = 0;
      let maxForce = 0;
      let maxIdx = 0;

      for (let i = 0; i < n; i++) {
        const f = forces.current[i];
        const ratio = f / totalForce;
        tx += Math.cos(angles[i]) * ratio;
        ty += Math.sin(angles[i]) * ratio;
        if (f > maxForce) { maxForce = f; maxIdx = i; }
      }

      // Clamp target to arena
      const tDist = Math.sqrt(tx * tx + ty * ty);
      if (tDist > arenaRadius) {
        tx = (tx / tDist) * arenaRadius;
        ty = (ty / tDist) * arenaRadius;
      }

      // Spring force toward target
      const pos = posRef.current;
      const vel = velRef.current;
      const ax = (tx - pos.x) * stiffness;
      const ay = (ty - pos.y) * stiffness;

      vel.x = (vel.x + ax) * damping;
      vel.y = (vel.y + ay) * damping;
      pos.x += vel.x;
      pos.y += vel.y;

      // Clamp position
      const pDist = Math.sqrt(pos.x * pos.x + pos.y * pos.y);
      if (pDist > arenaRadius) {
        pos.x = (pos.x / pDist) * arenaRadius;
        pos.y = (pos.y / pDist) * arenaRadius;
        // Bounce: reverse velocity component along radial
        const dot = (vel.x * pos.x + vel.y * pos.y) / (arenaRadius * arenaRadius);
        vel.x -= dot * pos.x * 0.5;
        vel.y -= dot * pos.y * 0.5;
      }

      // Decay forces slowly (so old pulls fade)
      for (let i = 0; i < n; i++) {
        forces.current[i] *= maxForceDecay;
      }

      // Compute per-team tensions (normalized)
      const tensionMax = Math.max(...forces.current, 1);
      const tensions = forces.current.map(f => Math.min(f / tensionMax, 1));
      const overallTension = Math.min(pDist / arenaRadius, 1);

      setState({
        knotX: pos.x,
        knotY: pos.y,
        teamTensions: tensions,
        totalTension: overallTension,
        dominantTeamIdx: maxIdx,
      });

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      activeRef.current = false;
      cancelAnimationFrame(rafRef.current);
    };
  }, [teamCount, damping, stiffness, maxForceDecay, arenaRadius]);

  return { ...state, applyPull, reset };
}
