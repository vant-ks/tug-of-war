# Rope Rendering System — INTEGRATION.md

## Overview

Self-contained rope physics and SVG rendering system for the Tug of War arena display. Zero external dependencies — pure React 18 + TypeScript + inline SVG.

## File Manifest

| File | Type | Purpose |
|---|---|---|
| `RopeRenderer.tsx` | Component | Individual rope SVG — braided strands, catenary sag, tension glow, pull pulse |
| `KnotRenderer.tsx` | Component | Center knot SVG — layered texture, strain indicators, jiggle, pulse ring |
| `RopeSnapEffect.tsx` | Component | Round-end snap animation — particle debris burst along each rope |
| `useRopePhysics.ts` | Hook | Spring-based knot position simulation — momentum, overshoot, damped settling |
| `usePullPulse.ts` | Hook | Per-team pulse timing — triggers traveling light effect on ropes |
| `RopeArenaAssembly.tsx` | Reference | Working demo wiring all pieces together (NOT a drop-in, it's a reference) |

## Architecture

```
BroadcastChannel "pull" message
        │
        ▼
  useRopePhysics.applyPull(teamIdx, power)
        │                                    usePullPulse.triggerPulse(teamIdx)
        │                                           │
        ▼                                           ▼
  knotX, knotY (normalized -1..1)            pulseStates[i] (bool)
  teamTensions[i] (0..1)                           │
  totalTension (0..1)                               │
  dominantTeamIdx                                   │
        │                                           │
        ▼                                           ▼
  ┌─────────────────────────────────────────────────────┐
  │                    <svg viewBox>                      │
  │                                                       │
  │   <RopeRenderer>  ← one per team                     │
  │     startX/Y = team anchor on arena edge              │
  │     endX/Y   = knot SVG coordinates                   │
  │     tension  = teamTensions[i]                        │
  │     pulseActive = pulseStates[i]                      │
  │     color    = team hex color                         │
  │                                                       │
  │   <KnotRenderer>  ← single instance                  │
  │     x/y      = knot SVG coordinates                   │
  │     totalTension, dominantColor, recentPull           │
  │                                                       │
  │   <RopeSnapEffect> ← active on round end             │
  │     knotX/Y  = normalized final position              │
  │     teams    = team array for colors                  │
  │                                                       │
  └───────────────────────────────────────────────────────┘
```

## Coordinate System

The physics hook works in **normalized space** (-1 to 1) where (0,0) is arena center.

To convert to SVG coordinates for rendering:

```tsx
const ARENA_CX = 400;   // SVG center X (half your viewBox width)
const ARENA_CY = 400;   // SVG center Y
const ARENA_R  = 320;   // arena circle radius in SVG units

const knotSvgX = ARENA_CX + knotX * (ARENA_R * 0.85);
const knotSvgY = ARENA_CY + knotY * (ARENA_R * 0.85);
```

Team anchors sit on the arena edge:

```tsx
const angle = (teamIndex / teamCount) * Math.PI * 2 - Math.PI / 2;
const anchorX = ARENA_CX + Math.cos(angle) * ARENA_R;
const anchorY = ARENA_CY + Math.sin(angle) * ARENA_R;
```

## Integration Steps

### 1. Copy files into your project

Place all `.tsx` and `.ts` files alongside your existing arena component, e.g.:

```
src/
  components/
    arena/
      RopeRenderer.tsx
      KnotRenderer.tsx
      RopeSnapEffect.tsx
    hooks/
      useRopePhysics.ts
      usePullPulse.ts
```

### 2. Initialize hooks in your ArenaDisplay

```tsx
const { knotX, knotY, teamTensions, totalTension, dominantTeamIdx, applyPull, reset }
  = useRopePhysics({ teamCount: teams.length });

const { pulseStates, triggerPulse, resetAll }
  = usePullPulse(teams.length);
```

### 3. Wire BroadcastChannel pulls to physics

In your existing `useBus` handler where you receive `msg.type === "pull"`:

```tsx
if (msg.type === "pull") {
  const teamIdx = teams.findIndex(t => t.id === msg.teamId);
  if (teamIdx >= 0) {
    applyPull(teamIdx, msg.power || 1);
    triggerPulse(teamIdx);
  }
}
```

### 4. Replace your existing rope lines with RopeRenderer

Remove the old `<line>` elements and replace with:

```tsx
{teams.map((t, i) => (
  <RopeRenderer
    key={`rope-${i}`}
    id={`rope-${i}`}
    startX={anchorX}  startY={anchorY}
    endX={knotSvgX}   endY={knotSvgY}
    color={TEAM_COLORS[t.colorIdx].bg}
    tension={teamTensions[i]}
    pulseActive={pulseStates[i]}
    teamName={t.name}
    thickness={5}
    strandCount={3}
    sagAmount={40}
  />
))}
```

### 5. Replace your existing knot circle with KnotRenderer

```tsx
<KnotRenderer
  x={knotSvgX} y={knotSvgY}
  size={14}
  totalTension={totalTension}
  dominantColor={TEAM_COLORS[teams[dominantTeamIdx].colorIdx].bg}
  isActive={phase === 'playing'}
  recentPull={/* brief true on each pull */}
/>
```

### 6. Add snap effect for round end

```tsx
<RopeSnapEffect
  active={phase === 'results'}
  knotX={knotX} knotY={knotY}
  teams={teams}
  arenaSize={800}
  onComplete={() => { /* show results panel */ }}
/>
```

### 7. Remove old physics code

The `useRopePhysics` hook replaces:
- Your `forceRef` accumulator
- The `requestAnimationFrame` tick that computes knot position
- The `teamForces` state object
- Manual `knotPos` lerping

## Tuning Parameters

### useRopePhysics

| Param | Default | Effect |
|---|---|---|
| `damping` | 0.92 | Higher = more sluggish, less overshoot. 0.85=bouncy, 0.96=heavy |
| `stiffness` | 0.004 | Higher = faster snap to target. 0.002=slow drift, 0.01=snappy |
| `maxForceDecay` | 0.995 | How fast old pulls fade. 0.99=fast fade, 0.999=sticky |
| `arenaRadius` | 0.9 | Max normalized distance knot can reach (prevents escaping circle) |

### RopeRenderer

| Param | Default | Effect |
|---|---|---|
| `thickness` | 4 | Base rope width in SVG units |
| `strandCount` | 3 | Visible braid strands (2=simple, 3=standard, 4=thick cable) |
| `sagAmount` | 30 | Max droop in SVG units when tension is zero |

### KnotRenderer

| Param | Default | Effect |
|---|---|---|
| `size` | 12 | Knot radius in SVG units |

## Rope Visual Breakdown

Each rope renders these SVG layers (bottom to top):

1. **Outer glow** — wide, blurred stroke in team color, intensity scales with tension
2. **Shadow** — dark version of team color for depth
3. **Braid strands** — 3 (default) sine-wave offset paths that weave across each other; weave amplitude dampens as tension increases (rope straightens)
4. **Specular highlight** — thin bright center line
5. **Pull pulse** — animated gradient traveling along rope when `pulseActive` is true
6. **Anchor nub** — small circle at the arena-edge end

The knot renders:

1. **Glow ring** — pulsing ring in dominant team color
2. **Shadow ellipse** — offset below for ground contact
3. **Body** — radial gradient from light rope color to strain color (shifts reddish under tension)
4. **Cross wraps** — 3 rotated ellipses simulating the knot's binding
5. **Inner core** — smaller circle
6. **Highlight** — specular spot
7. **Strain lines** — radial lines that appear above 50% tension
8. **Pulse ring** — expanding fade-out ring on recent pull
